<?php

return array(
    'host' => 'localhost',
    'dbname' => 'toys_shop',
    'user' => 'root',
    'password' => ''
);
?>